package screen;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import java.io.IOException;

public class MainScreenController {

    @FXML
    private AnchorPane rootLayout;

    @FXML
    private void initialize() {
        try {
            FXMLLoader controlLoader = new FXMLLoader(getClass().getResource("Control.fxml"));
            AnchorPane controlPanel = controlLoader.load();

            FXMLLoader graphLoader = new FXMLLoader(getClass().getResource("GraphGen.fxml"));
            AnchorPane graphPanel = graphLoader.load();

            // Set anchors for controlPanel
            AnchorPane.setTopAnchor(controlPanel, 0.0);
            AnchorPane.setLeftAnchor(controlPanel, 0.0);
            AnchorPane.setRightAnchor(controlPanel, 0.0);

            // Set anchors for graphPanel
            AnchorPane.setTopAnchor(graphPanel, controlPanel.getPrefHeight());
            AnchorPane.setLeftAnchor(graphPanel, 0.0);
            AnchorPane.setRightAnchor(graphPanel, 0.0);
            AnchorPane.setBottomAnchor(graphPanel, 0.0);

            // Add panels to the rootLayout
            rootLayout.getChildren().addAll(controlPanel, graphPanel);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
