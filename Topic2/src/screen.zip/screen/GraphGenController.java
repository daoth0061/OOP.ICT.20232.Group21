package screen;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import model.Graph;
import model.Node;
import model.Edge;

import java.util.*;


public class GraphGenController {

    @FXML
    private Canvas graphCanvas;

    @FXML
    private Button generateButton;

    @FXML
    private void handleGenerateButton() {
        Graph graph = new Graph(6, 20);
        System.out.println(graph.getAdjMatrix());
        System.out.println(graph.getEdges());
        System.out.println(graph.getNodes());

        drawGraph(graph);
    }

    private void drawGraph(Graph graph) {
        GraphicsContext gc = graphCanvas.getGraphicsContext2D();
        gc.clearRect(0, 0, graphCanvas.getWidth(), graphCanvas.getHeight());

        double width = graphCanvas.getWidth();
        double height = graphCanvas.getHeight();

        ArrayList<model.Node> nodeList = graph.getNodes();
        Set<model.Node> nodeSet = new HashSet<>(nodeList);
        Map<Node, List<Boolean>> adjMatrix = graph.getAdjMatrix();
        Set<Edge> edgeList = graph.getEdges();

        int n = nodeSet.size();
        double radius = 10;
        double centerX = width / 2;
        double centerY = height / 2;
        double angle = 360.0 / n;
        double[] x = new double[n];
        double[] y = new double[n];
        Node[] nodeArray = nodeSet.toArray(new Node[0]);

        // Tính toán tọa độ cho các đỉnh
        for (int i = 0; i < n; i++) {
            x[i] = centerX + 100 * Math.cos(Math.toRadians(i * angle));
            y[i] = centerY + 100 * Math.sin(Math.toRadians(i * angle));
        }

        // Vẽ các cạnh
        gc.setStroke(Color.BLACK);
        for (Edge edge : edgeList) {
            Iterator<Node> it = edge.getNodes().iterator();
            Node node1 = it.next();
            Node node2 = it.next();

            int index1 = -1, index2 = -1;
            for (int i = 0; i < n; i++) {
                if (nodeArray[i].equals(node1)) {
                    index1 = i;
                }
                if (nodeArray[i].equals(node2)) {
                    index2 = i;
                }
                if (index1 != -1 && index2 != -1) break;
            }
            if (index1 != -1 && index2 != -1) {
                gc.strokeLine(x[index1], y[index1], x[index2], y[index2]);
            }
        }

        // Vẽ các đỉnh
        gc.setFill(Color.RED);
        for (int i = 0; i < n; i++) {
            gc.fillOval(x[i] - radius, y[i] - radius, radius * 2, radius * 2);
            gc.setFill(Color.BLACK);
            gc.fillText(Character.toString(nodeArray[i].getValue()), x[i] - radius, y[i] - radius - 2);
            gc.setFill(Color.RED);
        }
    }
}