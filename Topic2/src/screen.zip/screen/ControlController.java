package screen;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class ControlController {

    @FXML
    private TextField numberOfNodesTextField;

    @FXML
    private TextField maxWeightTextField;

    @FXML
    private ComboBox<String> algorithmComboBox;

    @FXML
    public void initialize() {
        // Initial setup if needed
    }

    public int getNumberOfNodes() {
        try {
            return Integer.parseInt(numberOfNodesTextField.getText());
        } catch (NumberFormatException e) {
            // Handle invalid input
            return 0;
        }
    }

    public int getMaxWeight() {
        try {
            return Integer.parseInt(maxWeightTextField.getText());
        } catch (NumberFormatException e) {
            // Handle invalid input
            return 0;
        }
    }

    public String getSelectedAlgorithm() {
        return algorithmComboBox.getValue();
    }
}