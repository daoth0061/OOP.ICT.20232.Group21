package screen;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class TraversalController {

    @FXML
    private ListView<String> waitingListView;

    @FXML
    private ListView<String> visitedListView;

    @FXML
    private ListView<String> searchPathListView;

    @FXML
    public void initialize() {
        // Initial setup if needed
    }

    public void addToWaiting(String item) {
        waitingListView.getItems().add(item);
    }

    public void addToVisited(String item) {
        visitedListView.getItems().add(item);
    }

    public void addToSearchPath(String item) {
        searchPathListView.getItems().add(item);
    }
}
